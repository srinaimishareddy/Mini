from django.shortcuts import render , redirect
from django.http import HttpResponse
from django.forms import inlineformset_factory
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.decorators import login_required , user_passes_test
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
import secrets
import json
from django.contrib import messages
from .models import * 
from .forms import CreateUserForm , OrderForm
from .filters import *
# Create your views here.

 
def launch(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        return render(request, 'volunteer/landing.html')
def adminlogin(request):
    if request.user.is_authenticated:
        if request.user.is_superuser:
            return redirect('maker')
        else:
            return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password =request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('adminlogin')
            else:
                messages.info(request, 'Username OR password is incorrect')
        context = {}
        return render(request, 'volunteer/adminlogin.html', context) 

@login_required(login_url='login')
def home(request):
    if not Personal.objects.filter(volunteer=request.user).exists():
        vac = ['A', 'B']            
        group = secrets.choice(vac)
        dose = ['0.5' , '1.0' ]
        dose = secrets.choice(dose)
        form = OrderForm(initial = { 'volunteer': request.user ,'group': group , 'dose' : dose , 'final_update' : 'Positive' , 'updated' : '0' , 'delivery' : 0 } )
        if request.method == 'POST':
            form = OrderForm(request.POST)
            if form.is_valid():
                form.save()
                print("saved")
                messages.success(request, 'sucessfully ordered')
                return redirect('home')
            else:
                messages.error(request , 'invalid details')
                return redirect('home')
        context = {'form':form , 'button' : True }
        return render(request , 'volunteer/home.html' , context)
    else:
        if 'vaccine_form' in request.POST:
            print('yes')
            v_type = request.POST.get('type')
            print(v_type)
            v_dose = request.POST.get('dose')
            up = Personal.objects.get(volunteer = request.user)
            up.group = v_type
            up.dose = v_dose
            up.delivery = 1
            up.save()
        if 'result_submit' in request.POST:
            updated_detail = request.POST.get('update')
            up = Personal.objects.get(volunteer = request.user)
            up.final_update = updated_detail
            up.updated = '1';
            up.save()
            return redirect('home')
        up = Personal.objects.get(volunteer = request.user)
        return render(request , 'volunteer/home.html' , {'button' : False , "delivery" : up} )



@login_required(login_url='login')
def maker(request):
    if request.user.is_superuser:
        dp = Personal.objects.all()
        v_count = dp.count()
        p_count = dp.filter( final_update='Positive', updated = '1' ).count()
        count_ap = dp.filter( final_update='Positive', updated = '1' ,group = "A" ).count()
        count_bp = dp.filter( final_update='Positive', updated = '1' ,group = "B" ).count()
        t_count = dp.filter( updated = '1' ).count()
        count_1p = dp.filter( final_update='Positive', updated = '1' , dose = '1.0'  ,group = "A" ).count()
        count_1 = dp.filter(  updated = '1' , dose = '1.0' ,group = "A" ).count()
        count_5p = dp.filter( final_update='Positive', updated = '1' , dose = '0.5' ,group = "A" ).count()
        count_5 = dp.filter(  updated = '1' , dose = '0.5' ,group = "A" ).count()
        try:
            v1 = str(((t_count-p_count)/t_count)*100)+'%'
        except:
            v1 = 0
        try:
            v2 = str(((count_1-count_1p)/count_1)*100)+'%'
        except:
            v2 = 0
        try:
            v3 = str(((count_5-count_5p)/count_5)*100)+'%'
        except:
            v3 = 0
        
        context = {'table': dp , 'v_count': v_count , 'p_count' : p_count , 't_count' : t_count,'t_efficiency' : v1 , 'efficiency_1' :  v2 , 'efficiency_5' :  v3  , 'count_ap' : count_ap , 'count_bp' : count_bp } 
        return render(request , 'volunteer/maker.html'  , context )
    else:
        return redirect('home')

def register(request):
    if request.user.is_authenticated:
        return redirect('home')
    else:
        form = CreateUserForm()
        if request.method == 'POST':
            form = CreateUserForm(request.POST)
            if form.is_valid():
                form.save()
                user = form.cleaned_data.get('username')
                messages.success(request, 'Account was created for ' + user)
                return redirect('login')
        context = {'form':form}
        return render(request, 'volunteer/register.html', context)
def logoutUser(request):
    logout(request)
    return redirect('/')
def loginPage(request):
    if request.user.is_authenticated:
         return redirect('home')
    else:
        if request.method == 'POST':
            username = request.POST.get('username')
            password =request.POST.get('password')
            user = authenticate(request, username=username, password=password)
            if user is not None:
                login(request, user)
                return redirect('home')
            else:
                messages.info(request, 'Username OR password is incorrect')
        context = {}
        return render(request, 'volunteer/login.html', context)


def result(request):
    try:
        dpbf = Personal.objects.all()
        dpf = Myfilters(request.GET , queryset=dpbf)
        dp = dpf.qs
        v_count = dp.count()
        t_count = dp.filter( updated = '1').count()
        dop = dp.first()
        do = float(dop.dose)
        dov = dop.group
        tp_count = dp.filter( updated = '1' , final_update = 'Positive').count()
        try:
            v1 = str(((t_count-tp_count)/t_count)*100)
        except:
            v1 = 0
        response = json.dumps([{
                            "name":"SLCV2020",
                            "type":"vaccine",
                            "vaccineGroup": dov,
                            "dose": do ,
                            "efficacy_rate":v1,
                            "result":{
                            "volunteer":t_count,
                            "confirm_positive":tp_count
                            }
                            }], indent=4)
    except:
        response = json.dumps([{ "error" : "invalid call"}], indent=4)
    return HttpResponse(response , content_type ="text/json")
def all_result(request):
    dp = Personal.objects.all()
    v_count = dp.count()
    p_count = dp.filter( final_update='Positive', updated = '1' ).count()
    t_count = dp.filter( updated = '1' ).count()
    count_1p = dp.filter( final_update='Positive', updated = '1' , group = "A" ).count()
    count_1 = dp.filter(  updated = '1' , group = "A" ).count()
    count_5p = dp.filter( final_update='Positive', updated = '1' , group = "B" ).count()
    count_5 = dp.filter(  updated = '1' , group = "B" ).count()
    try:
        v2 = str(((count_1-count_1p)/count_1)*100)+'%'
    except:
        v2 = 0
    try:
        v3 = str(((count_5-count_5p)/count_5)*100)+'%'
    except:
        v3 = 0
    response = json.dumps([
                            {
                            "name":"SLCV2020",
                            "type":"vaccine",
                            "vaccineGroup":"A",
                            "efficacy_rate":v2,
                            "result":{
                                    "volunteer":count_1,
                                    "confirm_positive": count_1p
                                    }
                            },
                            {
                            "name":"Unknown",
                            "type":"placebo",
                            "vaccineGroup":v3,
                            "result":{
                            "volunteer":count_5,
                            "confirm_positive": count_5p
                            }
                            }], indent=4)
    return HttpResponse(response , content_type ="text/json")


    

    