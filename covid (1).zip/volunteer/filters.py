import django_filters
from .models import *

class Myfilters(django_filters.FilterSet):
    class Meta:
        model = Personal
        fields = '__all__'
