from django.contrib import admin
from django.urls import path , include
from django.http import HttpResponse
from . import views

urlpatterns = [
    path('', views.launch ),
    path('adminlogin/', views.adminlogin ,  name="adminlogin"),
    path('login/', views.loginPage ,  name="login"),
    path('register/', views.register, name="register"),
    path('logout/' , views.logoutUser , name="logout"),
    path('home/' , views.home , name="home"),
    path('maker/' , views.maker , name="maker"),
    path('vaccine/all_result/' , views.all_result , name="vaccine/all_result"),
    path('vaccine/result' , views.result , name="vaccine/result"),
]
