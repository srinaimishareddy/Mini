from django.apps import AppConfig


class VolunteerConfig(AppConfig):
    name = 'volunteer'
