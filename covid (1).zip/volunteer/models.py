from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class Personal(models.Model):
    GENDER = (('Female','Female'),('Male','Male'))
    FINAL_UPDATE =(('Positive','Positive'),('Negative','Negative'))
    volunteer = models.ForeignKey(User, null=True , on_delete = models.SET_NULL )
    gender = models.CharField(max_length=1000, null=True , choices=GENDER )
    health = models.CharField(max_length = 200 ,null=True)
    address = models.CharField(max_length = 500 ,null=True)
    age = models.CharField(max_length = 500 ,null=True)
    group = models.CharField(max_length = 200 ,null=True)
    dose = models.CharField(max_length=100, null=True)
    final_update = models.CharField(max_length=1000, null=True , choices=FINAL_UPDATE )
    postalcode = models.CharField(max_length=100, null=True)
    updated = models.CharField(max_length=100, null=True)
    delivery = models.CharField(max_length=100, null=True)