from django.contrib import admin
from .models import Personal

# Register your models here.
admin.site.register(Personal)